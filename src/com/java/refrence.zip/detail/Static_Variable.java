package com.java.detail;

public class Static_Variable {
 static int a=15,b=60;
  public static void multiply() {
	int a=12,b=25;
	System.out.println(a*b);
}
  public static void add() {
	  System.out.println(a+b);
}
  public static void main(String[] args) {
	add();
	multiply();
}
}
