package com.java.detail;

public class Do_While {

	public static void main(String[] args) {
         int n= 15;
		while (n>10) {
			n=n-2;
			System.out.println("TRUE");
			
		}
          do {
			System.out.println("FALSE");
		} while (n>25);
	}

}
