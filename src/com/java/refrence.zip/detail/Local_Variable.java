package com.java.detail;

public class Local_Variable {
 public void add() {
	 int a=50,b=25;
	 System.out.println(a+b);
	
}
 public static void main(String[] args) {
	Local_Variable a=new Local_Variable();
	a.add();
}
}
