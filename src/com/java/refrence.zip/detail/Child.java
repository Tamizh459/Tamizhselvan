package com.java.detail;

public class Child extends Parent{
 @Override
	public void discipline(String a) {
		// TODO Auto-generated method stub
		super.discipline(a);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
