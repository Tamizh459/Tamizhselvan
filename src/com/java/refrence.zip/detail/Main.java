package com.java.detail;

public class Main {
	public static void mani(int args) {
		System.out.println("hii");
	}
	
	public static void main(String[] santhosh) {
		System.out.println("Main");
		mani(32);
	}
	

}
