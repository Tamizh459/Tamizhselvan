package com.java.detail;

public class Keywords {
	
	int a=35;

	public static void main(String[] args) {
       System.out.println("MAIN METHOD");
      Keywords kw= new Keywords();
      kw.keywords();    
	}
	public void keywords() {
System.out.println("methods");
	}
	static {
		System.out.println("main");
	}

}
