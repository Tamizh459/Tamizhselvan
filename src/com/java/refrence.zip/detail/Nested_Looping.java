package com.java.detail;

public class Nested_Looping {
	public static void main(String[] args) {
		 for (int i = 0; i < 3.5; i++) {
			for (int j = 0; j < 2.5; j++) {
				System.out.println(i+" "+j);
			}
	}

	}
	}
