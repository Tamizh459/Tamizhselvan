package com.java.detail;

import java.util.HashMap;
import java.util.Map;

public class Map_Interface {
	public static void main(String[] args) {
		Map<Integer,String> a=new HashMap<Integer,String>();
		
		a.put(101,"siva");
		a.put(102,"arun");
		a.put(103,"raja");
		System.out.println(a);
		
		
		
	}

}
