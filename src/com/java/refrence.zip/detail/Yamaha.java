package com.java.detail;

public interface Yamaha {
	void milage1();

}
