package com.java.detail;

public class Movie {
 public void shortfilm(String a) {
	// TODO Auto-generated method stub
System.out.println(a);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Movie a=new Movie();
         a.shortfilm("JAVA");
	}

}
