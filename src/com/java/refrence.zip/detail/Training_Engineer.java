package com.java.detail;

import java.util.Scanner;

public class Training_Engineer {

	public static void main(String[] args) {
		Scanner name =new Scanner(System.in);
		
		System.out.println("Enter the Name");
              String a = name.nextLine();
              System.out.println(a);
              
              
              
         System.out.println("Enter the ID");
         int b=name.nextInt();
         System.out.println(b);	
System.out.println("Enter the Address");
String c= name.next();
System.out.println(c);
         
         
         
         
         
         
         
	}
}