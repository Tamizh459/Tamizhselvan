package com.java.detail;

public abstract class Government {
	public void engine() {
		System.out.println("The Engine-4 stroke");
	}
	public void speed() {
		System.out.println("The Speed-280");
	}
    public void cc() {
		System.out.println("The CC-360");
	}
    public abstract void model();
    public abstract void color();
	
	}


