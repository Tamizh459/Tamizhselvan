package com.java.detail;

public class Employee_Name {
	public static void main(String[] args) {
		int Rollno = 5;
		switch (Rollno) {
	
		case 1:
	System.out.println("Name is Tamizh1");		
			break;
		case 2:
			System.out.println("Name is Selva ");
			break;
		case 3:
			System.out.println("Name is Prakash");
			break;
		case 4:
			System.out.println("Name is Sathish");		
				break;
		case 5:
			System.out.println("Name is Vino");		
					break;
		case 6:
			System.out.println("Name is Saravana");		
					break;
		default:
			System.out.println("Noone");
			break;
		}
	}

}
