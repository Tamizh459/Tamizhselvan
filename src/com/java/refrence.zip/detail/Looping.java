package com.java.detail;

public class Looping {


	public static void main(String[] args) {
		
		for (int i = 0; i < 15; i++) {
			System.out.println("*");
		}
	}

}
