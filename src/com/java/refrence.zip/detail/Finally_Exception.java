package com.java.detail;

public class Finally_Exception {
	public static void main(String[] args) {
		try {
			System.out.println(15 / 0);
		} finally {
			
		System.out.println("THE PROGRAM GIVES OUTPUT");	
		}
	}

}
