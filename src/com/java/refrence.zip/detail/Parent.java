package com.java.detail;

public class Parent {
	public void discipline(String a) {
		// TODO Auto-generated method stub
System.out.println(a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Parent character=new Parent();
         character.discipline("good");
	}

}
