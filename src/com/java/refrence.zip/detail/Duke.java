package com.java.detail;

public interface Duke {
	void milage2 ();

}
